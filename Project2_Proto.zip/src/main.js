import { App } from './App.jsx';

App();
