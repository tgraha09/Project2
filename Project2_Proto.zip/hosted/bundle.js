import * as a from '../assets/index.16524689.js'
import * as b from '../assets/vendor.57c8bb31.js'
//import * as c from '../assets/index.8f77e6d6.css'
//c.type = "text/css"
